﻿namespace DotNetRecruit
{
    public struct AnagramCounter
    {
        public int WordLength { get; set; }

        public int Count { get; set; }
    }
}